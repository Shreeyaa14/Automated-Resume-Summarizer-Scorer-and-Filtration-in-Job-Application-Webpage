// Main JavaScript file for the career page
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 800,
        once: true
    });

    // Job search functionality
    const searchForm = document.querySelector('#searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const query = document.querySelector('#searchInput').value;
            const department = document.querySelector('#departmentFilter').value;
            const location = document.querySelector('#locationFilter').value;
            
            try {
                const response = await fetch(`/api/jobs/search?q=${query}&department=${department}&location=${location}`);
                const jobs = await response.json();
                updateJobListings(jobs);
            } catch (error) {
                console.error('Error searching jobs:', error);
            }
        });
    }

    // Job application handling
    const applicationForm = document.querySelector('#applicationForm');
    if (applicationForm) {
        applicationForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(applicationForm);
            
            try {
                const response = await fetch('/api/apply', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                if (response.ok) {
                    showApplicationSuccess(result);
                } else {
                    showApplicationError(result.error);
                }
            } catch (error) {
                console.error('Error submitting application:', error);
                showApplicationError('Failed to submit application. Please try again.');
            }
        });
    }

    // File upload preview
    const resumeInput = document.querySelector('#resume');
    if (resumeInput) {
        resumeInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const fileUpload = document.querySelector('.file-upload span');
                fileUpload.textContent = file.name;
            }
        });

        // Drag and drop handling
        const dropZone = document.querySelector('.file-upload');
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, unhighlight, false);
        });

        function highlight(e) {
            dropZone.classList.add('dragover');
        }

        function unhighlight(e) {
            dropZone.classList.remove('dragover');
        }

        dropZone.addEventListener('drop', handleDrop, false);

        function handleDrop(e) {
            const dt = e.dataTransfer;
            const file = dt.files[0];
            
            if (file && file.type === 'application/pdf') {
                resumeInput.files = dt.files;
                const fileUpload = document.querySelector('.file-upload span');
                fileUpload.textContent = file.name;
            } else {
                showApplicationError('Please upload a PDF file');
            }
        }
    }
});

// Helper functions
function updateJobListings(jobs) {
    const jobGrid = document.querySelector('.job-grid');
    if (!jobGrid) return;

    jobGrid.innerHTML = jobs.map(job => `
        <div class="job-card" data-aos="fade-up">
            <div class="job-header">
                <h3 class="job-title">${job.title}</h3>
                <span class="job-department">${job.department}</span>
            </div>
            <div class="job-details">
                <div class="job-detail-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${job.location}</span>
                </div>
                <div class="job-detail-item">
                    <i class="fas fa-briefcase"></i>
                    <span>${job.job_type}</span>
                </div>
                <div class="job-detail-item">
                    <i class="fas fa-clock"></i>
                    <span>${job.experience_level}</span>
                </div>
            </div>
            <p class="job-description">${job.description.substring(0, 150)}...</p>
            <div class="job-actions">
                <button class="apply-btn" onclick="openApplication(${job.id})">
                    <i class="fas fa-paper-plane"></i>
                    Apply Now
                </button>
            </div>
        </div>
    `).join('');
}

function showApplicationSuccess(result) {
    const status = document.querySelector('#applicationStatus');
    status.innerHTML = `
        <div class="status-success">
            <i class="fas fa-check-circle"></i>
            Application submitted successfully!
            <p>Your application ID is: ${result.application_id}</p>
        </div>
    `;
    document.querySelector('#applicationForm').reset();
}

function showApplicationError(error) {
    const status = document.querySelector('#applicationStatus');
    status.innerHTML = `
        <div class="status-error">
            <i class="fas fa-exclamation-circle"></i>
            ${error}
        </div>
    `;
}

function openApplication(jobId) {
    const modal = document.querySelector('#applicationModal');
    const jobIdInput = document.querySelector('#position');
    jobIdInput.value = jobId;
    modal.style.display = 'block';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.querySelector('#applicationModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}

// Close modal when clicking the close button
document.querySelector('.close').onclick = function() {
    document.querySelector('#applicationModal').style.display = 'none';
}
