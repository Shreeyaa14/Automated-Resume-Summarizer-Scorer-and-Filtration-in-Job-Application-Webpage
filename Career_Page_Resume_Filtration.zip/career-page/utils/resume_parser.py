import os
import PyPDF2
import docx
import spacy
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load spaCy model
nlp = spacy.load('en_core_web_sm')

class ResumeParser:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words='english')
        
    def extract_text_from_pdf(self, pdf_path):
        """Extract text from PDF file"""
        try:
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ''
                for page in pdf_reader.pages:
                    text += page.extract_text()
                return text
        except Exception as e:
            print(f"Error extracting text from PDF: {e}")
            return None

    def extract_text_from_docx(self, docx_path):
        """Extract text from DOCX file"""
        try:
            doc = docx.Document(docx_path)
            text = ' '.join([paragraph.text for paragraph in doc.paragraphs])
            return text
        except Exception as e:
            print(f"Error extracting text from DOCX: {e}")
            return None

    def extract_text(self, file_path):
        """Extract text based on file extension"""
        _, ext = os.path.splitext(file_path)
        if ext.lower() == '.pdf':
            return self.extract_text_from_pdf(file_path)
        elif ext.lower() in ['.docx', '.doc']:
            return self.extract_text_from_docx(file_path)
        return None

    def generate_summary(self, text):
        """Generate a summary of the resume"""
        doc = nlp(text)
        
        # Extract key information
        summary = {
            'skills': [],
            'education': [],
            'experience': [],
            'key_points': []
        }
        
        # Process each sentence
        for sent in doc.sents:
            # Look for education-related sentences
            if any(edu_term in sent.text.lower() for edu_term in ['degree', 'university', 'college', 'education']):
                summary['education'].append(sent.text.strip())
            
            # Look for experience-related sentences
            if any(exp_term in sent.text.lower() for exp_term in ['experience', 'worked', 'work', 'job', 'position']):
                summary['experience'].append(sent.text.strip())
        
        # Extract skills (entities labeled as SKILL by spaCy)
        for ent in doc.ents:
            if ent.label_ == 'SKILL':
                summary['skills'].append(ent.text)
        
        # Extract additional key points
        key_sentences = [sent.text.strip() for sent in doc.sents 
                        if any(keyword in sent.text.lower() 
                            for keyword in ['achieved', 'developed', 'led', 'managed', 'created'])]
        summary['key_points'] = key_sentences[:5]  # Top 5 key points
        
        return summary

    def calculate_match_score(self, resume_text, job_description):
        """Calculate match score between resume and job description"""
        try:
            # Create TF-IDF matrix
            tfidf_matrix = self.vectorizer.fit_transform([resume_text, job_description])
            
            # Calculate cosine similarity
            match_score = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            
            return float(match_score)
        except Exception as e:
            print(f"Error calculating match score: {e}")
            return 0.0

    def save_summary(self, summary, output_path):
        """Save resume summary to a JSON file"""
        try:
            with open(output_path, 'w') as f:
                json.dump(summary, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving summary: {e}")
            return False

    def process_resume(self, resume_path, job_description, output_dir):
        """Process resume and return match score and summary"""
        # Extract text from resume
        resume_text = self.extract_text(resume_path)
        if not resume_text:
            return None, None, 0.0
        
        # Generate summary
        summary = self.generate_summary(resume_text)
        
        # Calculate match score
        match_score = self.calculate_match_score(resume_text, job_description)
        
        # Save summary
        file_name = os.path.splitext(os.path.basename(resume_path))[0]
        summary_path = os.path.join(output_dir, f"{file_name}_summary.json")
        self.save_summary(summary, summary_path)
        
        # Add resume name to tracking file
        tracking_file = os.path.join(output_dir, "processed_resumes.txt")
        with open(tracking_file, "a") as f:
            f.write(f"{file_name}: Match Score = {match_score:.2f}\n")
        
        return summary, summary_path, match_score
