from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, create_engine
from sqlalchemy.orm import relationship, declarative_base
from werkzeug.security import generate_password_hash, check_password_hash
import json

Base = declarative_base()

class Job(Base):
    __tablename__ = 'job'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(100), nullable=False)
    department = Column(String(50), nullable=False)
    location = Column(String(50), nullable=False)
    description = Column(Text, nullable=False)
    requirements = Column(Text, nullable=False)
    salary_range = Column(String(50))
    job_type = Column(String(20), nullable=False)
    experience_level = Column(String(20), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String(20), default='active')
    applications = relationship('Application', backref='job', lazy=True)
    skills = relationship('JobSkill', backref='job', lazy=True)
    referrals = relationship('Referral', backref='job', lazy=True)

class JobSkill(Base):
    __tablename__ = 'job_skill'
    
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey('job.id'), nullable=False)
    skill = Column(String(50), nullable=False)
    importance = Column(Integer, default=1)  # 1: Required, 2: Preferred

class Candidate(Base):
    __tablename__ = 'candidate'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256))
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    phone = Column(String(20))
    resume_url = Column(String(200))
    created_at = Column(DateTime, default=datetime.utcnow)
    applications = relationship('Application', backref='candidate', lazy=True)
    skills = relationship('CandidateSkill', backref='candidate', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class CandidateSkill(Base):
    __tablename__ = 'candidate_skill'
    
    id = Column(Integer, primary_key=True)
    candidate_id = Column(Integer, ForeignKey('candidate.id'), nullable=False)
    skill = Column(String(50), nullable=False)
    years_experience = Column(Integer)
    proficiency_level = Column(String(20))

class Application(Base):
    __tablename__ = 'application'
    
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey('job.id'), nullable=False)
    candidate_id = Column(Integer, ForeignKey('candidate.id'), nullable=False)
    status = Column(String(20), default='applied')
    cover_letter = Column(Text)
    resume_path = Column(String(500))
    resume_summary = Column(String(500))
    match_score = Column(Float)
    applied_at = Column(DateTime, default=datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    notes = relationship('ApplicationNote', backref='application', lazy=True)
    interviews = relationship('Interview', backref='application', lazy=True)
    timeline = relationship('ApplicationTimeline', backref='application', lazy=True)

class ApplicationNote(Base):
    __tablename__ = 'application_note'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application.id'), nullable=False)
    note = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(Integer, ForeignKey('recruiter.id'), nullable=False)

class Interview(Base):
    __tablename__ = 'interview'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application.id'), nullable=False)
    interviewer_id = Column(Integer, ForeignKey('recruiter.id'), nullable=False)
    scheduled_at = Column(DateTime, nullable=False)
    interview_type = Column(String(20), nullable=False)
    status = Column(String(20), default='scheduled')
    feedback = Column(Text)
    rating = Column(Integer)

class Recruiter(Base):
    __tablename__ = 'recruiter'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    role = Column(String(20), default='recruiter')
    department = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class JobAlert(Base):
    __tablename__ = 'job_alert'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(120), nullable=False)
    keywords = Column(String(500), nullable=False)
    departments = Column(String(500), nullable=False)
    locations = Column(String(500), nullable=False)
    frequency = Column(String(20), nullable=False, default='daily')  # daily, weekly
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    last_sent_at = Column(DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'keywords': json.loads(self.keywords),
            'departments': json.loads(self.departments),
            'locations': json.loads(self.locations),
            'frequency': self.frequency,
            'created_at': self.created_at.isoformat(),
            'last_sent_at': self.last_sent_at.isoformat() if self.last_sent_at else None
        }

class Referral(Base):
    __tablename__ = 'referral'
    
    id = Column(Integer, primary_key=True)
    referrer_email = Column(String(120), nullable=False)
    candidate_email = Column(String(120), nullable=False)
    job_id = Column(Integer, ForeignKey('job.id'), nullable=False)
    notes = Column(Text)
    status = Column(String(20), nullable=False, default='pending')  # pending, applied, hired
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'referrer_email': self.referrer_email,
            'candidate_email': self.candidate_email,
            'job_id': self.job_id,
            'job_title': self.job.title,
            'notes': self.notes,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }

class ApplicationTimeline(Base):
    __tablename__ = 'application_timeline'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application.id'), nullable=False)
    status = Column(String(50), nullable=False)
    notes = Column(Text)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'status': self.status,
            'notes': self.notes,
            'created_at': self.created_at.isoformat()
        }

class EmailSubscription(Base):
    __tablename__ = 'email_subscription'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(120), unique=True, nullable=False)
    subscribed_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'subscribed_at': self.subscribed_at.isoformat()
        }

class CareerPath(Base):
    __tablename__ = 'career_path'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    department = Column(String(100), nullable=False)
    description = Column(Text)
    levels = relationship('CareerLevel', backref='career_path', lazy=True)
    learning_resources = relationship('LearningResource', backref='career_path', lazy=True)

class CareerLevel(Base):
    __tablename__ = 'career_level'
    
    id = Column(Integer, primary_key=True)
    career_path_id = Column(Integer, ForeignKey('career_path.id'), nullable=False)
    level = Column(Integer, nullable=False)
    title = Column(String(200), nullable=False)
    required_skills = Column(Text, nullable=False)  # JSON string
    required_experience = Column(String(50))
    responsibilities = Column(Text, nullable=False)  # JSON string

class LearningResource(Base):
    __tablename__ = 'learning_resource'
    
    id = Column(Integer, primary_key=True)
    career_path_id = Column(Integer, ForeignKey('career_path.id'))
    title = Column(String(200), nullable=False)
    type = Column(String(50))  # course, book, video, etc.
    url = Column(String(500))
    description = Column(Text)
    skills = Column(Text)  # JSON string
    level = Column(String(20))  # beginner, intermediate, advanced
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'type': self.type,
            'url': self.url,
            'description': self.description,
            'skills': json.loads(self.skills) if self.skills else [],
            'level': self.level,
            'created_at': self.created_at.isoformat()
        }

class EmployeeStory(Base):
    __tablename__ = 'employee_story'
    
    id = Column(Integer, primary_key=True)
    employee_name = Column(String(100), nullable=False)
    title = Column(String(200), nullable=False)
    department = Column(String(100), nullable=False)
    years_at_company = Column(Integer)
    content = Column(Text, nullable=False)
    image_url = Column(String(500))
    video_url = Column(String(500))
    career_growth = Column(Text)
    achievements = Column(Text)  # JSON string
    advice = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class CompanyValue(Base):
    __tablename__ = 'company_value'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    icon = Column(String(50))

class CompanyBenefit(Base):
    __tablename__ = 'company_benefit'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(50))  # health, financial, lifestyle, etc.
    icon = Column(String(50))

class CompanyEvent(Base):
    __tablename__ = 'company_event'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    date = Column(DateTime, nullable=False)
    location = Column(String(200))
    type = Column(String(50))  # team building, celebration, training, etc.
    image_url = Column(String(500))

class OfficeLocation(Base):
    __tablename__ = 'office_location'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    address = Column(Text, nullable=False)
    city = Column(String(100), nullable=False)
    country = Column(String(100), nullable=False)
    latitude = Column(Float)
    longitude = Column(Float)
    image_url = Column(String(500))
    amenities = Column(Text)  # JSON string

class CompanyAward(Base):
    __tablename__ = 'company_award'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    organization = Column(String(200), nullable=False)
    year = Column(Integer, nullable=False)
    description = Column(Text)
    image_url = Column(String(500))

class SkillTest(Base):
    __tablename__ = 'skill_test'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    skills = Column(Text)  # JSON string
    duration = Column(Integer)  # in minutes
    passing_score = Column(Float)
    questions = Column(Text)  # JSON string
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def calculate_score(self, answers):
        questions = json.loads(self.questions)
        correct_answers = {q['id']: q['correct_answer'] for q in questions}
        score = 0
        for answer in answers:
            if answer['question_id'] in correct_answers:
                if answer['answer'] == correct_answers[answer['question_id']]:
                    score += 1
        return (score / len(questions)) * 100
    
    def generate_feedback(self, answers):
        questions = json.loads(self.questions)
        feedback = []
        for answer in answers:
            question = next((q for q in questions if q['id'] == answer['question_id']), None)
            if question:
                is_correct = answer['answer'] == question['correct_answer']
                feedback.append({
                    'question_id': answer['question_id'],
                    'correct': is_correct,
                    'explanation': question.get('explanation', '')
                })
        return feedback
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'skills': json.loads(self.skills) if self.skills else [],
            'duration': self.duration,
            'passing_score': self.passing_score,
            'created_at': self.created_at.isoformat()
        }

class TestSession(Base):
    __tablename__ = 'test_session'
    
    id = Column(Integer, primary_key=True)
    test_id = Column(Integer, ForeignKey('skill_test.id'), nullable=False)
    candidate_id = Column(Integer, ForeignKey('candidate.id'), nullable=False)
    started_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime)
    expires_at = Column(DateTime, nullable=False)
    score = Column(Float)
    answers = Column(Text)  # JSON string
    
    test = relationship('SkillTest', backref='sessions')
    candidate = relationship('Candidate', backref='test_sessions')

class InterviewFeedback(Base):
    __tablename__ = 'interview_feedback'
    
    id = Column(Integer, primary_key=True)
    interview_id = Column(Integer, ForeignKey('interview.id'), nullable=False)
    interviewer_id = Column(Integer, ForeignKey('recruiter.id'), nullable=False)
    technical_score = Column(Float)
    communication_score = Column(Float)
    culture_fit_score = Column(Float)
    strengths = Column(Text)
    areas_for_improvement = Column(Text)
    notes = Column(Text)
    recommendation = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    interviewer = relationship('Recruiter', backref='feedback_given')
    
    def to_dict(self):
        return {
            'id': self.id,
            'interview_id': self.interview_id,
            'interviewer_id': self.interviewer_id,
            'technical_score': self.technical_score,
            'communication_score': self.communication_score,
            'culture_fit_score': self.culture_fit_score,
            'strengths': self.strengths,
            'areas_for_improvement': self.areas_for_improvement,
            'notes': self.notes,
            'recommendation': self.recommendation,
            'created_at': self.created_at.isoformat()
        }

class OnboardingChecklist(Base):
    __tablename__ = 'onboarding_checklist'
    
    id = Column(Integer, primary_key=True)
    department = Column(String(100), nullable=False)
    steps = Column(Text, nullable=False)  # JSON string
    documents_required = Column(Text)  # JSON string
    training_modules = Column(Text)  # JSON string
    team_introductions = Column(Text)  # JSON string
    resources = Column(Text)  # JSON string
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class OnboardingProgress(Base):
    __tablename__ = 'onboarding_progress'
    
    id = Column(Integer, primary_key=True)
    application_id = Column(Integer, ForeignKey('application.id'), nullable=False)
    step_id = Column(String(50), nullable=False)
    status = Column(String(20), nullable=False)  # pending, in_progress, completed
    notes = Column(Text)
    completed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    application = relationship('Application', backref='onboarding_progress')
    
    def to_dict(self):
        return {
            'id': self.id,
            'step_id': self.step_id,
            'status': self.status,
            'notes': self.notes,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

# Create tables
if __name__ == '__main__':
    engine = create_engine('sqlite:///career_portal.db')
    Base.metadata.create_all(engine)
