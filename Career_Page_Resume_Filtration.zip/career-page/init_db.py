from models import Base, Job, JobSkill
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# Create database engine
engine = create_engine('sqlite:///career_portal.db')
Base.metadata.create_all(engine)

# Create session
Session = sessionmaker(bind=engine)
session = Session()

def init_jobs():
    # Clear existing data
    try:
        session.query(JobSkill).delete()
        session.query(Job).delete()
        session.commit()
    except Exception as e:
        print(f"Error clearing existing data: {e}")
        session.rollback()

    # Sample jobs data
    jobs = [
        {
            'title': 'Senior Software Engineer - Full Stack',
            'department': 'Engineering',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '5-8 years',
            'description': '''We are seeking a Senior Full Stack Engineer to join our growing team. You will be responsible for developing and maintaining our core applications, mentoring junior developers, and contributing to architectural decisions.

Key Responsibilities:
- Design and implement scalable web applications
- Lead technical initiatives and mentor junior developers
- Collaborate with product managers and designers
- Optimize application performance
- Ensure code quality through testing and reviews

Requirements:
- 5+ years of experience in full-stack development
- Strong proficiency in Python, JavaScript, and modern web frameworks
- Experience with React/Angular/Vue.js
- Strong understanding of database design and optimization
- Experience with cloud platforms (AWS/Azure/GCP)''',
            'requirements': '''Requirements:
- 5+ years of experience in full-stack development
- Strong proficiency in Python, JavaScript, and modern web frameworks
- Experience with React/Angular/Vue.js
- Strong understanding of database design and optimization
- Experience with cloud platforms (AWS/Azure/GCP)''',
            'skills': ['Python', 'JavaScript', 'React', 'Node.js', 'SQL', 'AWS', 'System Design']
        },
        {
            'title': 'DevOps Engineer',
            'department': 'Engineering',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '3-6 years',
            'description': '''We're looking for a DevOps Engineer to help us build and maintain our cloud infrastructure and deployment pipelines.

Key Responsibilities:
- Design and implement CI/CD pipelines
- Manage cloud infrastructure and security
- Monitor system performance and reliability
- Automate operational processes
- Collaborate with development teams

Requirements:
- 3+ years of DevOps experience
- Strong knowledge of AWS/Azure/GCP
- Experience with containerization and orchestration
- Proficiency in scripting languages
- Understanding of security best practices''',
            'requirements': '''Requirements:
- 3+ years of DevOps experience
- Strong knowledge of AWS/Azure/GCP
- Experience with containerization and orchestration
- Proficiency in scripting languages
- Understanding of security best practices''',
            'skills': ['AWS', 'Docker', 'Kubernetes', 'Jenkins', 'Terraform', 'Linux', 'Python']
        },
        {
            'title': 'UI/UX Designer',
            'department': 'Design',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '3-5 years',
            'description': '''Join our design team to create beautiful and intuitive user experiences for our products.

Key Responsibilities:
- Create user-centered designs and workflows
- Develop UI mockups and prototypes
- Conduct user research and testing
- Create design systems and style guides
- Collaborate with developers and stakeholders

Requirements:
- 3+ years of UI/UX design experience
- Strong portfolio demonstrating web/mobile designs
- Proficiency in design tools (Figma, Adobe XD)
- Understanding of user-centered design principles
- Experience with design systems''',
            'requirements': '''Requirements:
- 3+ years of UI/UX design experience
- Strong portfolio demonstrating web/mobile designs
- Proficiency in design tools (Figma, Adobe XD)
- Understanding of user-centered design principles
- Experience with design systems''',
            'skills': ['Figma', 'Adobe XD', 'User Research', 'Prototyping', 'Design Systems', 'HTML/CSS']
        },
        {
            'title': 'Product Manager',
            'department': 'Product',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '4-7 years',
            'description': '''We are looking for a Product Manager to drive the strategy and execution of our product initiatives.

Key Responsibilities:
- Define product strategy and roadmap
- Gather and analyze user requirements
- Work with engineering and design teams
- Conduct market research
- Track and measure product metrics

Requirements:
- 4+ years of product management experience
- Strong analytical and problem-solving skills
- Excellent communication abilities
- Experience with agile methodologies
- Technical background preferred''',
            'requirements': '''Requirements:
- 4+ years of product management experience
- Strong analytical and problem-solving skills
- Excellent communication abilities
- Experience with agile methodologies
- Technical background preferred''',
            'skills': ['Product Strategy', 'Agile', 'Data Analysis', 'User Stories', 'Market Research', 'JIRA']
        },
        {
            'title': 'Quality Assurance Engineer',
            'department': 'Engineering',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '2-5 years',
            'description': '''Join our QA team to ensure the quality and reliability of our products.

Key Responsibilities:
- Design and execute test plans
- Automate test cases and scenarios
- Perform functional and regression testing
- Report and track bugs
- Collaborate with developers

Requirements:
- 2+ years of QA experience
- Experience with test automation tools
- Knowledge of testing methodologies
- Strong attention to detail
- Good communication skills''',
            'requirements': '''Requirements:
- 2+ years of QA experience
- Experience with test automation tools
- Knowledge of testing methodologies
- Strong attention to detail
- Good communication skills''',
            'skills': ['Selenium', 'Python', 'Test Planning', 'API Testing', 'JIRA', 'SQL']
        },
        {
            'title': 'Data Scientist',
            'department': 'Analytics',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '3-6 years',
            'description': '''We're seeking a Data Scientist to help us derive insights from our data and build predictive models.

Key Responsibilities:
- Develop machine learning models
- Analyze large datasets
- Create data visualizations
- Build data pipelines
- Present findings to stakeholders

Requirements:
- 3+ years of data science experience
- Strong background in statistics and ML
- Proficiency in Python and SQL
- Experience with ML frameworks
- Good communication skills''',
            'requirements': '''Requirements:
- 3+ years of data science experience
- Strong background in statistics and ML
- Proficiency in Python and SQL
- Experience with ML frameworks
- Good communication skills''',
            'skills': ['Python', 'Machine Learning', 'SQL', 'TensorFlow', 'Data Visualization', 'Statistics']
        },
        {
            'title': 'Technical Support Engineer',
            'department': 'Customer Support',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '1-3 years',
            'description': '''Join our support team to help customers succeed with our products.

Key Responsibilities:
- Provide technical support to customers
- Troubleshoot software issues
- Document solutions and best practices
- Collaborate with engineering team
- Improve support processes

Requirements:
- 1+ years of technical support experience
- Strong problem-solving skills
- Excellent communication abilities
- Basic programming knowledge
- Customer-focused mindset''',
            'requirements': '''Requirements:
- 1+ years of technical support experience
- Strong problem-solving skills
- Excellent communication abilities
- Basic programming knowledge
- Customer-focused mindset''',
            'skills': ['Technical Support', 'Troubleshooting', 'Customer Service', 'Documentation', 'JIRA']
        },
        {
            'title': 'HR Business Partner',
            'department': 'Human Resources',
            'location': 'Mysore, Karnataka',
            'job_type': 'Full-time',
            'experience_level': '4-7 years',
            'description': '''We are looking for an HR Business Partner to support our growing team.

Key Responsibilities:
- Partner with department leaders
- Manage employee relations
- Drive talent development initiatives
- Handle performance management
- Implement HR policies

Requirements:
- 4+ years of HR experience
- Strong understanding of HR practices
- Excellent interpersonal skills
- Experience with HRIS systems
- Knowledge of labor laws''',
            'requirements': '''Requirements:
- 4+ years of HR experience
- Strong understanding of HR practices
- Excellent interpersonal skills
- Experience with HRIS systems
- Knowledge of labor laws''',
            'skills': ['HR Management', 'Employee Relations', 'Talent Development', 'Performance Management', 'HRIS']
        }
    ]

    # Add jobs to database
    for job_data in jobs:
        skills = job_data.pop('skills')
        job = Job(
            **job_data,
            created_at=datetime.utcnow(),
            status='active'
        )
        session.add(job)
        session.flush()  # Get the job ID

        # Add skills for the job
        for skill_name in skills:
            skill = JobSkill(
                job_id=job.id,
                skill=skill_name
            )
            session.add(skill)

    try:
        session.commit()
        print("Successfully initialized jobs data")
    except Exception as e:
        print(f"Error adding jobs: {e}")
        session.rollback()
    finally:
        session.close()

if __name__ == '__main__':
    init_jobs()
