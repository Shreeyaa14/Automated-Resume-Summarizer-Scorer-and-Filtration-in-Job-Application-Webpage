// Sample jobs data
const jobs = [
    {
        id: 1,
        title: "Senior Software Engineer",
        department: "Engineering",
        location: "Bangalore, India",
        job_type: "Full-time",
        experience_level: "5+ years",
        salary: "₹25L - ₹35L per annum",
        description: "We are seeking an experienced Software Engineer to join our core engineering team. You will be responsible for designing and implementing high-performance, scalable software solutions.",
        responsibilities: [
            "Design and implement scalable backend services",
            "Lead technical architecture discussions and decisions",
            "Mentor junior developers and conduct code reviews",
            "Collaborate with product managers to define features",
            "Optimize application performance and reliability"
        ],
        requirements: [
            "5+ years of experience in software development",
            "Strong proficiency in Python, Java, or similar languages",
            "Experience with distributed systems and microservices",
            "Knowledge of cloud platforms (AWS/Azure/GCP)",
            "Excellent problem-solving and communication skills"
        ],
        skills: [
            { skill: "Python" },
            { skill: "Java" },
            { skill: "AWS" },
            { skill: "Microservices" },
            { skill: "System Design" }
        ]
    },
    {
        id: 2,
        title: "UX/UI Designer",
        department: "Design",
        location: "Bangalore, India",
        job_type: "Full-time",
        experience_level: "3-5 years",
        salary: "₹15L - ₹25L per annum",
        description: "We're looking for a talented UX/UI Designer to create exceptional user experiences. You'll work closely with product and engineering teams to design intuitive interfaces.",
        responsibilities: [
            "Create user-centered designs by understanding business requirements",
            "Develop UI mockups and prototypes",
            "Conduct user research and usability testing",
            "Create user flows, wireframes, and visual designs",
            "Collaborate with developers for implementation"
        ],
        requirements: [
            "3-5 years of experience in UX/UI design",
            "Strong portfolio demonstrating UI/UX projects",
            "Proficiency in Figma, Sketch, or similar tools",
            "Understanding of user-centered design principles",
            "Experience with design systems"
        ],
        skills: [
            { skill: "Figma" },
            { skill: "UI Design" },
            { skill: "User Research" },
            { skill: "Prototyping" },
            { skill: "Design Systems" }
        ]
    },
    {
        id: 3,
        title: "Product Manager",
        department: "Product",
        location: "Bangalore, India",
        job_type: "Full-time",
        experience_level: "4+ years",
        salary: "₹20L - ₹30L per annum",
        description: "We are looking for an experienced Product Manager to drive product strategy and execution. You will work with cross-functional teams to deliver impactful products.",
        responsibilities: [
            "Define product vision, strategy, and roadmap",
            "Gather and analyze user requirements",
            "Work with engineering teams on implementation",
            "Drive product launches and go-to-market strategy",
            "Analyze metrics and make data-driven decisions"
        ],
        requirements: [
            "4+ years of product management experience",
            "Strong analytical and problem-solving skills",
            "Experience with agile development methodologies",
            "Excellent communication and leadership abilities",
            "Technical background preferred"
        ],
        skills: [
            { skill: "Product Strategy" },
            { skill: "Agile" },
            { skill: "Data Analysis" },
            { skill: "Stakeholder Management" },
            { skill: "Technical Background" }
        ]
    },
    {
        id: 4,
        title: "DevOps Engineer",
        department: "Engineering",
        location: "Bangalore, India",
        job_type: "Full-time",
        experience_level: "3+ years",
        salary: "₹18L - ₹28L per annum",
        description: "Join our DevOps team to build and maintain scalable infrastructure. You'll work on automating processes and improving our deployment pipeline.",
        responsibilities: [
            "Design and implement CI/CD pipelines",
            "Manage cloud infrastructure and deployments",
            "Automate operational processes",
            "Monitor system performance and reliability",
            "Implement security best practices"
        ],
        requirements: [
            "3+ years of DevOps experience",
            "Strong knowledge of AWS/Azure/GCP",
            "Experience with Docker and Kubernetes",
            "Proficiency in scripting languages",
            "Understanding of security principles"
        ],
        skills: [
            { skill: "AWS" },
            { skill: "Docker" },
            { skill: "Kubernetes" },
            { skill: "CI/CD" },
            { skill: "Infrastructure as Code" }
        ]
    }
];

// Function to display jobs
function displayJobs(jobs) {
    const jobsGrid = document.getElementById('jobsGrid');
    jobsGrid.innerHTML = jobs.map(job => `
        <div class="job-card" data-job-id="${job.id}" data-aos="fade-up">
            <div class="job-card-header">
                <h2 class="job-title">${job.title}</h2>
                <div class="job-department">${job.department}</div>
            </div>
            
            <div class="job-meta">
                <div class="job-meta-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${job.location}</span>
                </div>
                <div class="job-meta-item">
                    <i class="fas fa-clock"></i>
                    <span>${job.job_type}</span>
                </div>
                <div class="job-meta-item">
                    <i class="fas fa-briefcase"></i>
                    <span>${job.experience_level}</span>
                </div>
                <div class="job-meta-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>${job.salary}</span>
                </div>
            </div>

            <div class="job-description">
                <p>${job.description}</p>
            </div>

            <div class="job-details">
                <div class="details-section">
                    <h3>Key Responsibilities</h3>
                    <ul>
                        ${job.responsibilities.map(resp => `<li>${resp}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="details-section">
                    <h3>Requirements</h3>
                    <ul>
                        ${job.requirements.map(req => `<li>${req}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="job-skills">
                ${job.skills.map(skill => `<span class="skill-tag">${skill.skill}</span>`).join('')}
            </div>

            <button onclick="openApplicationModal(${job.id}, '${job.title}')" class="apply-button">
                <span>Apply Now</span>
                <i class="fas fa-arrow-right"></i>
            </button>
        </div>
    `).join('');

    // Initialize search and filter functionality
    initializeSearch();
}

// Function to handle file input change
function handleFileSelect(event) {
    const file = event.target.files[0];
    const fileNameDisplay = document.getElementById('selectedFileName');
    if (file) {
        fileNameDisplay.textContent = file.name;
        fileNameDisplay.style.display = 'block';
    } else {
        fileNameDisplay.textContent = '';
        fileNameDisplay.style.display = 'none';
    }
}

// Function to handle drag and drop
function handleDrop(event) {
    const dt = event.dataTransfer;
    const file = dt.files[0];
    const fileInput = document.getElementById('resume');
    const fileNameDisplay = document.getElementById('selectedFileName');
    
    fileInput.files = dt.files;
    if (file) {
        fileNameDisplay.textContent = file.name;
        fileNameDisplay.style.display = 'block';
    }
}

// Function to open application modal
function openApplicationModal(jobId, jobTitle) {
    document.getElementById('jobTitleSpan').textContent = jobTitle;
    const modal = new bootstrap.Modal(document.getElementById('applicationModal'));
    
    // Reset form and messages
    document.getElementById('applicationForm').reset();
    document.getElementById('selectedFileName').style.display = 'none';
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('successMessage').style.display = 'none';
    
    // Add file input event listener
    const fileInput = document.getElementById('resume');
    fileInput.addEventListener('change', handleFileSelect);
    
    // Add drag and drop event listeners
    const dropZone = document.querySelector('.file-upload-container');
    dropZone.addEventListener('drop', handleDrop);
    
    // Store the job ID for form submission
    document.getElementById('applicationForm').dataset.jobId = jobId;
    
    modal.show();
}

// Handle form submission
function handleFormSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const jobId = form.dataset.jobId;
    const formData = new FormData();
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';
    submitButton.disabled = true;
    
    // Reset messages
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('successMessage').style.display = 'none';
    
    // Add form fields to formData
    formData.append('name', document.getElementById('name').value);
    formData.append('email', document.getElementById('email').value);
    formData.append('phone', document.getElementById('phone').value);
    formData.append('experience', document.getElementById('experience').value);
    formData.append('coverLetter', document.getElementById('coverLetter').value);
    
    // Add resume file
    const resumeFile = document.getElementById('resume').files[0];
    if (resumeFile) {
        formData.append('resume', resumeFile);
    }

    // Submit the form
    fetch(`/api/apply/${jobId}`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('successMessage').textContent = 'Application submitted successfully!';
            document.getElementById('successMessage').style.display = 'block';
            setTimeout(() => {
                bootstrap.Modal.getInstance(document.getElementById('applicationModal')).hide();
                form.reset();
            }, 2000);
        } else {
            document.getElementById('errorMessage').textContent = 'Error: ' + (data.error || 'Failed to submit application');
            document.getElementById('errorMessage').style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('errorMessage').textContent = 'Error submitting application. Please try again.';
        document.getElementById('errorMessage').style.display = 'block';
    })
    .finally(() => {
        // Reset button state
        submitButton.innerHTML = originalButtonText;
        submitButton.disabled = false;
    });
}

// Initialize search and filter
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    const categorySelect = document.getElementById('categorySelect');

    // Search functionality
    searchInput.addEventListener('input', () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categorySelect.value.toLowerCase();
        filterJobs(searchTerm, selectedCategory);
    });

    // Category filter
    categorySelect.addEventListener('change', () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categorySelect.value.toLowerCase();
        filterJobs(searchTerm, selectedCategory);
    });
}

// Filter jobs based on search term and category
function filterJobs(searchTerm, category) {
    const filteredJobs = jobs.filter(job => {
        const matchesSearch = 
            job.title.toLowerCase().includes(searchTerm) ||
            job.description.toLowerCase().includes(searchTerm) ||
            job.department.toLowerCase().includes(searchTerm);
            
        const matchesCategory = category === 'all' || job.department.toLowerCase() === category;
        
        return matchesSearch && matchesCategory;
    });
    
    displayJobs(filteredJobs);
}

// Initialize the page
displayJobs(jobs);
