# Standard library imports
import os
import time
from datetime import datetime
from functools import wraps
from flask import (
    Flask, 
    request, 
    jsonify, 
    send_from_directory, 
    render_template,
    redirect,
    url_for,
    abort,
    flash,
    session,
    g
)
from flask_cors import CORS
from flask_mail import Mail, Message
from werkzeug.utils import secure_filename
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, DateTime, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, backref
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import spacy
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import PyPDF2
import re

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')

app = Flask(__name__, 
    static_folder='static',
    static_url_path='/static',
    template_folder='templates'  # Point to the templates directory
)

# App configuration
app.config.update(
    MAIL_SERVER = 'smtp.gmail.com',
    MAIL_PORT = 587,
    MAIL_USE_TLS = True,
    MAIL_USERNAME = os.getenv('MAIL_USERNAME', 'your-email@gmail.com'),
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', 'your-app-password'),
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads'),
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
)

# Create upload directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Enable CORS
CORS(app, resources={
    r"/*": {
        "origins": "*",
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

# Initialize Flask-Mail
mail = Mail(app)

# Configuration
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
MINIMUM_MATCH_SCORE = 0.6  # 60% match required

# Initialize extensions
mail = Mail(app)

# Database setup
Base = declarative_base()

# Define database models
class Job(Base):
    __tablename__ = 'jobs'
    
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    department = Column(String(100), nullable=False)
    location = Column(String(100), nullable=False)
    type = Column(String(50), nullable=False)  # Full-time, Part-time, Contract, Internship
    description = Column(Text, nullable=False)
    requirements = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Application(Base):
    __tablename__ = 'applications'
    
    id = Column(Integer, primary_key=True)
    job_id = Column(Integer, ForeignKey('jobs.id'), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    resume_path = Column(String(500), nullable=False)
    cover_letter = Column(Text)
    match_score = Column(Float, nullable=False, default=0.0)
    status = Column(String(20), nullable=False, default='pending')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Define the relationship with Job
    job = relationship('Job', backref=backref('applications', lazy=True, cascade='all, delete-orphan'))

# Create database engine
engine = create_engine('sqlite:///career_portal.db')

# Create all tables
Base.metadata.drop_all(engine)  # Drop existing tables
Base.metadata.create_all(engine)  # Create new tables

# Create session factory
Session = sessionmaker(bind=engine)

# Resume processing class
class ResumeProcessor:
    @staticmethod
    def extract_text(file_path):
        try:
            if file_path.endswith('.pdf'):
                import PyPDF2
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    text = ''
                    for page in reader.pages:
                        text += page.extract_text()
                    return text
            elif file_path.endswith('.doc') or file_path.endswith('.docx'):
                import docx
                doc = docx.Document(file_path)
                text = ''
                for para in doc.paragraphs:
                    text += para.text + '\n'
                return text
            return ''
        except Exception as e:
            print(f"Error extracting text from resume: {str(e)}")
            return ''

    @staticmethod
    def calculate_score(resume_text, job_requirements):
        try:
            # Convert texts to lowercase for better matching
            resume_text = resume_text.lower()
            job_requirements = job_requirements.lower()
            
            # Split requirements into individual skills/keywords
            requirements = [r.strip() for r in job_requirements.split('\n') if r.strip()]
            
            # Calculate matches
            total_requirements = len(requirements)
            matches = 0
            
            for req in requirements:
                # Remove bullet points and common prefixes
                req = req.replace('-', '').replace('•', '').strip()
                if req in resume_text:
                    matches += 1
            
            # Calculate score as percentage
            score = (matches / total_requirements) if total_requirements > 0 else 0
            return score
        except Exception as e:
            print(f"Error calculating resume score: {str(e)}")
            return 0

def calculate_match_score(job_requirements, resume_text, application_data):
    """
    Calculate match score between job requirements and candidate profile
    Returns a score between 0 and 100
    
    Weights:
    - Required Skills Match: 40%
    - Experience Level Match: 30%
    - Education Match: 20%
    - Cover Letter Quality: 10%
    """
    try:
        total_score = 0
        
        # 1. Required Skills Match (40%)
        required_skills = extract_skills(job_requirements)
        candidate_skills = extract_skills(resume_text)
        
        if required_skills:
            skills_match = len(set(required_skills) & set(candidate_skills)) / len(required_skills)
            skills_score = skills_match * 40
        else:
            skills_score = 40  # If no required skills specified, give full score
        
        print(f"Skills Score: {skills_score}/40")
        print(f"Required Skills: {required_skills}")
        print(f"Candidate Skills: {candidate_skills}")
        
        # 2. Experience Level Match (30%)
        required_years = extract_years_experience(job_requirements)
        candidate_years = extract_years_experience(resume_text)
        
        if required_years > 0:
            if candidate_years >= required_years:
                experience_score = 30
            else:
                experience_score = (candidate_years / required_years) * 30
        else:
            experience_score = 30  # If no experience requirement, give full score
        
        print(f"Experience Score: {experience_score}/30")
        print(f"Required Years: {required_years}")
        print(f"Candidate Years: {candidate_years}")
        
        # 3. Education Match (20%)
        required_education = extract_education(job_requirements)
        candidate_education = extract_education(resume_text)
        
        education_levels = {
            'high school': 1,
            'associate': 2,
            'bachelor': 3,
            'master': 4,
            'phd': 5,
            'doctorate': 5
        }
        
        if required_education:
            required_level = education_levels.get(required_education.lower(), 0)
            candidate_level = education_levels.get(candidate_education.lower(), 0)
            
            if candidate_level >= required_level:
                education_score = 20
            else:
                education_score = (candidate_level / required_level) * 20
        else:
            education_score = 20  # If no education requirement, give full score
        
        print(f"Education Score: {education_score}/20")
        print(f"Required Education: {required_education}")
        print(f"Candidate Education: {candidate_education}")
        
        # 4. Cover Letter Quality (10%)
        if application_data.get('cover_letter'):
            # Extract keywords from job description
            job_keywords = extract_keywords(job_requirements)
            
            # Extract keywords from cover letter
            cover_letter_keywords = extract_keywords(application_data['cover_letter'])
            
            # Calculate keyword match ratio
            if job_keywords:
                keyword_match = len(set(job_keywords) & set(cover_letter_keywords)) / len(job_keywords)
                cover_letter_score = keyword_match * 10
            else:
                cover_letter_score = 10  # If no keywords found in job description
        else:
            cover_letter_score = 0  # No cover letter provided
        
        print(f"Cover Letter Score: {cover_letter_score}/10")
        
        # Calculate total score
        total_score = skills_score + experience_score + education_score + cover_letter_score
        print(f"Total Match Score: {total_score}/100")
        
        return total_score
        
    except Exception as e:
        print(f"Error calculating match score: {str(e)}")
        return 0

def extract_skills(text):
    """Extract skills from text"""
    try:
        # Common technical skills and keywords
        common_skills = {
            'python', 'java', 'javascript', 'react', 'angular', 'vue', 'node.js', 
            'sql', 'nosql', 'mongodb', 'postgresql', 'mysql', 'oracle',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'devops',
            'html', 'css', 'sass', 'less', 'bootstrap', 'tailwind',
            'git', 'jenkins', 'ci/cd', 'agile', 'scrum', 'jira',
            'machine learning', 'ai', 'data science', 'tensorflow', 'pytorch',
            'rest', 'graphql', 'microservices', 'api', 'oauth', 'jwt'
        }
        
        # Tokenize and clean text
        tokens = word_tokenize(text.lower())
        stop_words = set(stopwords.words('english'))
        
        # Remove stop words and short words
        keywords = [
            token for token in tokens 
            if token not in stop_words 
            and len(token) > 2 
            and token.isalnum()
        ]
        
        # Extract skills
        skills = []
        for token in keywords:
            if token in common_skills:
                skills.append(token)
        
        # Look for compound skills (e.g., "machine learning")
        text_lower = text.lower()
        for skill in common_skills:
            if ' ' in skill and skill in text_lower:
                skills.append(skill)
        
        return list(set(skills))  # Remove duplicates
        
    except Exception as e:
        print(f"Error extracting skills: {str(e)}")
        return []

def extract_years_experience(text):
    """Extract years of experience from text"""
    try:
        # Common patterns for experience requirements
        patterns = [
            r'(\d+)\+?\s*(?:years?|yrs?).+?experience',
            r'experience.+?(\d+)\+?\s*(?:years?|yrs?)',
            r'(\d+)\+?\s*(?:years?|yrs?).+?work',
            r'work.+?(\d+)\+?\s*(?:years?|yrs?)'
        ]
        
        text_lower = text.lower()
        
        for pattern in patterns:
            match = re.search(pattern, text_lower)
            if match:
                return int(match.group(1))
        
        return 0
        
    except Exception as e:
        print(f"Error extracting years of experience: {str(e)}")
        return 0

def extract_education(text):
    """Extract education level from text"""
    try:
        education_keywords = {
            'phd': 'phd',
            'doctorate': 'doctorate',
            'master': 'master',
            'bachelor': 'bachelor',
            'associate': 'associate',
            'high school': 'high school'
        }
        
        text_lower = text.lower()
        
        for keyword, level in education_keywords.items():
            if keyword in text_lower:
                return level
        
        return None
        
    except Exception as e:
        print(f"Error extracting education: {str(e)}")
        return None

def extract_keywords(text):
    """Extract important keywords from text"""
    try:
        # Tokenize and clean text
        tokens = word_tokenize(text.lower())
        stop_words = set(stopwords.words('english'))
        
        # Remove stop words and short words
        keywords = [
            token for token in tokens 
            if token not in stop_words 
            and len(token) > 2 
            and token.isalnum()
        ]
        
        return list(set(keywords))  # Remove duplicates
        
    except Exception as e:
        print(f"Error extracting keywords: {str(e)}")
        return []

# Helper functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Error handling
class APIError(Exception):
    def __init__(self, message, status_code=400):
        super().__init__()
        self.message = message
        self.status_code = status_code

@app.errorhandler(APIError)
def handle_api_error(error):
    response = jsonify({'error': error.message})
    response.status_code = error.status_code
    return response

@app.errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    # db.rollback()
    return jsonify({'error': 'Internal server error'}), 500

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/<path:filename>')
def serve_file(filename):
    try:
        return send_from_directory('templates', filename)
    except Exception:
        return render_template('index.html')

# Health check endpoint
@app.route('/api/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    })

@app.route('/api/jobs', methods=['GET'])
def get_jobs():
    try:
        session = Session()
        jobs = session.query(Job).filter_by(is_active=True).all()
        return jsonify([{
            'id': job.id,
            'title': job.title,
            'department': job.department,
            'location': job.location,
            'job_type': job.type,
            'description': job.description,
            'requirements': job.requirements,
        } for job in jobs])
    except Exception as e:
        raise APIError(str(e))

@app.route('/api/jobs/<int:job_id>', methods=['GET'])
def get_job(job_id):
    session = Session()
    try:
        job = session.query(Job).filter_by(id=job_id).first()
        if not job:
            return jsonify({'error': 'Job not found'}), 404
            
        return jsonify({
            'id': job.id,
            'title': job.title,
            'department': job.department,
            'location': job.location,
            'job_type': job.type,
            'description': job.description,
            'requirements': job.requirements,
        })
    finally:
        session.close()

@app.route('/api/jobs/search', methods=['GET'])
def search_jobs():
    try:
        session = Session()
        query = request.args.get('q', '').lower()
        department = request.args.get('department', '').lower()
        
        jobs_query = session.query(Job).filter_by(is_active=True)
        
        if department:
            jobs_query = jobs_query.filter(func.lower(Job.department) == department)
        
        if query:
            jobs_query = jobs_query.filter(
                db.or_(
                    func.lower(Job.title).contains(query),
                    func.lower(Job.description).contains(query),
                    func.lower(Job.requirements).contains(query),
                    func.lower(Job.department).contains(query),
                    func.lower(Job.location).contains(query)
                )
            )
        
        jobs = jobs_query.all()
        return jsonify([{
            'id': job.id,
            'title': job.title,
            'department': job.department,
            'location': job.location,
            'job_type': job.type,
            'description': job.description,
            'requirements': job.requirements,
        } for job in jobs])
    except Exception as e:
        raise APIError(str(e))

@app.route('/api/jobs/filters', methods=['GET'])
def get_job_filters():
    session = Session()
    departments = session.query(Job.department).distinct().all()
    locations = session.query(Job.location).distinct().all()
    job_types = session.query(Job.type).distinct().all()

    return jsonify({
        'departments': [d[0] for d in departments],
        'locations': [l[0] for l in locations],
        'job_types': [t[0] for t in job_types]
    })

@app.route('/api/jobs/recommended', methods=['GET'])
def get_recommended_jobs():
    candidate_id = request.args.get('candidate_id')
    if not candidate_id:
        raise APIError('Candidate ID is required')

    session = Session()
    candidate = session.query(Candidate).get_or_404(candidate_id)
    candidate_skills = [skill.skill for skill in candidate.skills]

    # Get all active jobs
    jobs = session.query(Job).filter_by(is_active=True).all()
    
    # Calculate job scores based on skill match
    job_scores = []
    for job in jobs:
        job_skills = [skill.skill for skill in job.skills]
        skill_match = len(set(candidate_skills) & set(job_skills)) / len(job_skills) if job_skills else 0
        
        # Consider candidate's previous applications
        applied_before = session.query(Application).filter_by(
            candidate_id=candidate_id,
            job_id=job.id
        ).first() is not None
        
        if not applied_before:
            job_scores.append({
                'job': job,
                'score': skill_match
            })
    
    # Sort by score and get top 5
    recommended_jobs = sorted(job_scores, key=lambda x: x['score'], reverse=True)[:5]
    
    return jsonify([{
        'id': item['job'].id,
        'title': item['job'].title,
        'department': item['job'].department,
        'location': item['job'].location,
        'match_score': round(item['score'] * 100, 2),
    } for item in recommended_jobs])

@app.route('/api/jobs/<int:job_id>/similar', methods=['GET'])
def get_similar_jobs(job_id):
    session = Session()
    job = session.query(Job).get_or_404(job_id)
    job_skills = [skill.skill for skill in job.skills]
    
    # Get other active jobs in the same department
    similar_jobs = session.query(Job).filter(
        Job.is_active == True,
        Job.department == job.department,
        Job.id != job_id
    ).all()
    
    # Calculate similarity scores
    job_scores = []
    for similar_job in similar_jobs:
        similar_skills = [skill.skill for skill in similar_job.skills]
        skill_match = len(set(job_skills) & set(similar_skills)) / len(job_skills) if job_skills else 0
        
        if skill_match > 0.3:  # Only include jobs with >30% skill match
            job_scores.append({
                'job': similar_job,
                'score': skill_match
            })
    
    # Sort by score and get top 3
    similar_jobs = sorted(job_scores, key=lambda x: x['score'], reverse=True)[:3]
    
    return jsonify([{
        'id': item['job'].id,
        'title': item['job'].title,
        'department': item['job'].department,
        'location': item['job'].location,
        'similarity_score': round(item['score'] * 100, 2)
    } for item in similar_jobs])

@app.route('/api/jobs/<int:job_id>/analytics', methods=['GET'])
def get_job_analytics(job_id):
    session = Session()
    job = session.query(Job).get_or_404(job_id)
    
    # Get all applications for this job
    applications = session.query(Application).filter_by(job_id=job_id).all()
    
    # Calculate statistics
    total_applications = len(applications)
    if total_applications == 0:
        return jsonify({
            'total_applications': 0,
            'average_scores': None,
            'status_distribution': None,
            'application_trend': None
        })
    
    # Calculate average scores
    avg_scores = {
        'resume_score': sum(a.resume_score or 0 for a in applications) / total_applications,
        'experience_score': sum(a.experience_score or 0 for a in applications) / total_applications,
        'skills_match_score': sum(a.skills_match_score or 0 for a in applications) / total_applications,
        'overall_score': sum(a.overall_score or 0 for a in applications) / total_applications
    }
    
    # Calculate status distribution
    status_counts = {}
    for app in applications:
        status_counts[app.status] = status_counts.get(app.status, 0) + 1
    
    # Calculate application trend (last 30 days)
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    daily_counts = {}
    for app in applications:
        if app.applied_at >= thirty_days_ago:
            date_key = app.applied_at.date().isoformat()
            daily_counts[date_key] = daily_counts.get(date_key, 0) + 1
    
    return jsonify({
        'total_applications': total_applications,
        'average_scores': avg_scores,
        'status_distribution': status_counts,
        'application_trend': daily_counts
    })

@app.route('/api/jobs/apply', methods=['POST'])
def apply_for_job():
    try:
        print("=== Form Data ===")
        print("Form:", request.form)
        print("Files:", request.files)

        # Get form data
        job_id = request.form.get('jobId')
        first_name = request.form.get('firstName')
        last_name = request.form.get('lastName')
        email = request.form.get('email')
        phone = request.form.get('phone')
        cover_letter = request.form.get('coverLetter', '')

        print("=== Parsed Form Data ===")
        print(f"Job ID: {job_id}")
        print(f"First Name: {first_name}")
        print(f"Last Name: {last_name}")
        print(f"Email: {email}")
        print(f"Phone: {phone}")

        # Validate required fields
        required_fields = {
            'firstName': first_name,
            'lastName': last_name,
            'email': email,
            'phone': phone,
            'jobId': job_id
        }

        missing_fields = [field for field, value in required_fields.items() if not value]
        if missing_fields:
            error_msg = f'Missing required fields: {", ".join(missing_fields)}'
            print(f"=== Validation Error ===")
            print(error_msg)
            return jsonify({
                'error': error_msg
            }), 400

        # Check if resume was uploaded
        if 'resume' not in request.files:
            print("=== Error: No Resume ===")
            return jsonify({'error': 'No resume uploaded'}), 400
        
        file = request.files['resume']
        if file.filename == '':
            print("=== Error: Empty Filename ===")
            return jsonify({'error': 'No selected file'}), 400
        
        if not allowed_file(file.filename):
            print(f"=== Error: Invalid File Type ===")
            print(f"Filename: {file.filename}")
            return jsonify({'error': 'Invalid file type'}), 400

        print("=== All Validation Passed ===")

        # Create database session
        session = Session()

        # Get job details
        job = session.query(Job).filter_by(id=job_id).first()
        if not job:
            print(f"=== Error: Job Not Found ===")
            print(f"Job ID: {job_id}")
            return jsonify({'error': 'Job not found'}), 404

        # Save resume file
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        print(f"=== Resume Saved ===")
        print(f"Path: {file_path}")

        # Process resume
        parser = ResumeProcessor()
        resume_text = parser.extract_text(file_path)
        match_score = parser.calculate_score(resume_text, job.requirements)
        print(f"=== Resume Processed ===")
        print(f"Match Score: {match_score}")

        # Check if resume matches job requirements
        if match_score < MINIMUM_MATCH_SCORE:
            # Clean up uploaded file
            os.remove(file_path)
            print(f"=== Error: Low Match Score ===")
            print(f"Score: {match_score}")
            return jsonify({
                'error': 'Your profile does not match the job requirements',
                'match_score': match_score
            }), 400

        # Create application record
        application = Application(
            job_id=job_id,
            first_name=first_name,
            last_name=last_name,
            email=email,
            phone=phone,
            resume_path=file_path,
            cover_letter=cover_letter,
            match_score=match_score,
            status='pending' if match_score >= MINIMUM_MATCH_SCORE else 'rejected',
            created_at=datetime.utcnow()
        )

        session.add(application)
        session.commit()
        print(f"=== Application Created ===")
        print(f"ID: {application.id}")

        return jsonify({
            'message': 'Application submitted successfully',
            'match_score': match_score,
            'application_id': application.id
        }), 200

    except Exception as e:
        print(f"=== Error ===")
        print(f"Type: {type(e).__name__}")
        print(f"Message: {str(e)}")
        if 'session' in locals():
            session.rollback()
        if 'file_path' in locals() and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except:
                pass
        return jsonify({'error': str(e)}), 500

    finally:
        if 'session' in locals():
            session.close()

@app.route('/api/applications/<int:application_id>/status', methods=['GET'])
def get_application_status(application_id):
    session = Session()
    application = session.query(Application).get_or_404(application_id)
    
    # Get interview schedule if any
    interview = session.query(Interview).filter_by(application_id=application_id).order_by(Interview.scheduled_at.desc()).first()
    
    # Get application timeline
    timeline = session.query(ApplicationTimeline).filter_by(application_id=application_id).order_by(ApplicationTimeline.created_at.desc()).all()
    
    return jsonify({
        'status': application.status,
        'applied_at': application.applied_at.isoformat(),
        'last_updated': application.updated_at.isoformat(),
        'scores': {
            'resume_score': application.resume_score,
            'experience_score': application.experience_score,
            'skills_match_score': application.skills_match_score,
            'overall_score': application.overall_score
        },
        'interview': interview.to_dict() if interview else None,
        'timeline': [t.to_dict() for t in timeline]
    })

@app.route('/api/applications/<int:application_id>/withdraw', methods=['POST'])
def withdraw_application(application_id):
    session = Session()
    application = session.query(Application).get_or_404(application_id)
    
    if application.status in ['withdrawn', 'rejected', 'hired']:
        raise APIError('Cannot withdraw application in current status')
    
    application.status = 'withdrawn'
    application.updated_at = datetime.utcnow()
    
    timeline = ApplicationTimeline(
        application_id=application_id,
        status='withdrawn',
        notes='Application withdrawn by candidate'
    )
    session.add(timeline)
    session.commit()
    
    # Send notification email
    try:
        send_status_update_email(
            application.email,
            'Application Withdrawn',
            'withdrawn',
            application.job.title
        )
    except Exception as e:
        print(f"Failed to send email: {str(e)}")
    
    return jsonify({'message': 'Application withdrawn successfully'})

@app.route('/api/job-alerts', methods=['POST'])
def create_job_alert():
    data = request.json
    required_fields = ['email', 'keywords', 'departments', 'locations']
    for field in required_fields:
        if field not in data:
            raise APIError(f'{field.replace("_", " ").title()} is required')
    
    alert = JobAlert(
        email=data['email'],
        keywords=data['keywords'],
        departments=data['departments'],
        locations=data['locations'],
        frequency=data.get('frequency', 'daily')
    )
    session = Session()
    session.add(alert)
    session.commit()
    
    return jsonify({
        'message': 'Job alert created successfully',
        'alert_id': alert.id
    })

@app.route('/api/job-alerts/<int:alert_id>', methods=['DELETE'])
def delete_job_alert(alert_id):
    session = Session()
    alert = session.query(JobAlert).get_or_404(alert_id)
    session.delete(alert)
    session.commit()
    
    return jsonify({'message': 'Job alert deleted successfully'})

@app.route('/api/referrals', methods=['POST'])
def create_referral():
    data = request.json
    required_fields = ['referrer_email', 'candidate_email', 'job_id']
    for field in required_fields:
        if field not in data:
            raise APIError(f'{field.replace("_", " ").title()} is required')
    
    # Check if job exists
    session = Session()
    job = session.query(Job).get_or_404(data['job_id'])
    
    # Create referral
    referral = Referral(
        referrer_email=data['referrer_email'],
        candidate_email=data['candidate_email'],
        job_id=data['job_id'],
        notes=data.get('notes', '')
    )
    session.add(referral)
    session.commit()
    
    # Send referral invitation email
    try:
        send_referral_email(
            data['candidate_email'],
            data['referrer_email'],
            job.title,
            data.get('notes', '')
        )
    except Exception as e:
        print(f"Failed to send referral email: {str(e)}")
    
    return jsonify({
        'message': 'Referral created successfully',
        'referral_id': referral.id
    })

@app.route('/api/parse-resume', methods=['POST'])
def parse_resume():
    if 'resume' not in request.files:
        raise APIError('No resume file provided')
    
    file = request.files['resume']
    if file.filename == '':
        raise APIError('No selected file')
    
    if not allowed_file(file.filename):
        raise APIError('Invalid file format. Only PDF and DOCX files are allowed')
    
    # Save file temporarily
    filename = secure_filename(file.filename)
    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(temp_path)
    
    try:
        # Parse resume
        resume_data = ResumeProcessor.extract_text(temp_path)
        
        # Get job details if job_id provided
        job_id = request.form.get('job_id')
        if job_id:
            session = Session()
            job = session.query(Job).get_or_404(job_id)
            job_data = {
                'required_skills': [skill.skill for skill in job.skills],
                'required_years': int(job.experience_level.split('-')[0]),
                'required_education': job.requirements,
                'description': job.description
            }
            # scores = ResumeProcessor.calculate_similarity(resume_data, job_data)
        else:
            # scores = None
            pass
        
        return jsonify({
            'parsed_data': resume_data,
            # 'scores': scores
        })
    
    finally:
        # Clean up temporary file
        if os.path.exists(temp_path):
            os.remove(temp_path)

@app.route('/api/subscribe', methods=['POST'])
def subscribe_email():
    data = request.json
    if 'email' not in data:
        raise APIError('Email is required')
    
    subscription = EmailSubscription(
        email=data['email'],
        subscribed_at=datetime.utcnow()
    )
    session = Session()
    session.add(subscription)
    session.commit()
    
    # Send welcome email
    try:
        send_welcome_email(data['email'])
    except Exception as e:
        print(f"Failed to send welcome email: {str(e)}")
    
    return jsonify({'message': 'Subscribed successfully'})

@app.route('/api/unsubscribe', methods=['POST'])
def unsubscribe_email():
    data = request.json
    if 'email' not in data:
        raise APIError('Email is required')
    
    session = Session()
    subscription = session.query(EmailSubscription).filter_by(email=data['email']).first()
    if subscription:
        session.delete(subscription)
        session.commit()
    
    return jsonify({'message': 'Unsubscribed successfully'})

@app.route('/api/recruiter/dashboard', methods=['GET'])
def recruiter_dashboard():
    # Add authentication here
    session = Session()
    recent_applications = session.query(Application).order_by(
        Application.applied_at.desc()
    ).limit(10).all()
    
    pending_interviews = session.query(Interview).filter_by(
        status='scheduled'
    ).order_by(Interview.scheduled_at).all()
    
    return jsonify({
        'recent_applications': [{
            'id': app.id,
            'job_title': app.job.title,
            'candidate_name': f"{app.first_name} {app.last_name}",
            'applied_at': app.applied_at.isoformat(),
            'overall_score': app.overall_score
        } for app in recent_applications],
        'pending_interviews': [{
            'id': interview.id,
            'candidate_name': f"{interview.application.first_name} {interview.application.last_name}",
            'job_title': interview.application.job.title,
            'scheduled_at': interview.scheduled_at.isoformat(),
            'interview_type': interview.interview_type
        } for interview in pending_interviews]
    })

# Career Growth and Learning Paths
@app.route('/api/career-paths', methods=['GET'])
def get_career_paths():
    department = request.args.get('department')
    session = Session()
    paths = session.query(CareerPath).filter_by(department=department).all() if department else session.query(CareerPath).all()
    
    return jsonify([{
        'id': path.id,
        'title': path.title,
        'department': path.department,
        'description': path.description,
        'levels': [{
            'level': level.level,
            'title': level.title,
            'skills': json.loads(level.required_skills),
            'experience': level.required_experience,
            'responsibilities': json.loads(level.responsibilities)
        } for level in path.levels],
        'learning_resources': [{
            'title': resource.title,
            'type': resource.type,
            'url': resource.url,
            'description': resource.description
        } for resource in path.learning_resources]
    } for path in paths])

@app.route('/api/learning-resources', methods=['GET'])
def get_learning_resources():
    skill = request.args.get('skill')
    level = request.args.get('level', 'beginner')
    
    session = Session()
    resources = session.query(LearningResource).filter(
        LearningResource.skills.contains(skill),
        LearningResource.level == level
    ).all() if skill else session.query(LearningResource).all()
    
    return jsonify([resource.to_dict() for resource in resources])

# Employee Stories and Testimonials
@app.route('/api/employee-stories', methods=['GET'])
def get_employee_stories():
    department = request.args.get('department')
    session = Session()
    stories = session.query(EmployeeStory).filter_by(department=department).all() if department else session.query(EmployeeStory).all()
    
    return jsonify([{
        'id': story.id,
        'employee_name': story.employee_name,
        'title': story.title,
        'department': story.department,
        'years_at_company': story.years_at_company,
        'content': story.content,
        'image_url': story.image_url,
        'video_url': story.video_url,
        'career_growth': story.career_growth,
        'achievements': json.loads(story.achievements),
        'advice': story.advice,
        'created_at': story.created_at.isoformat()
    } for story in stories])

# Company Culture and Benefits
@app.route('/api/company-culture', methods=['GET'])
def get_company_culture():
    session = Session()
    return jsonify({
        'values': session.query(CompanyValue).all(),
        'benefits': session.query(CompanyBenefit).all(),
        'events': session.query(CompanyEvent).filter(
            CompanyEvent.date >= datetime.utcnow()
        ).order_by(CompanyEvent.date.asc()).all(),
        'office_locations': session.query(OfficeLocation).all(),
        'awards': session.query(CompanyAward).order_by(CompanyAward.year.desc()).all()
    })

# Skill Assessment Tests
@app.route('/api/skill-tests', methods=['GET'])
def get_skill_tests():
    job_id = request.args.get('job_id')
    session = Session()
    if job_id:
        job = session.query(Job).get_or_404(job_id)
        tests = session.query(SkillTest).filter(
            SkillTest.skills.overlap(job.required_skills)
        ).all()
    else:
        tests = session.query(SkillTest).all()
    
    return jsonify([test.to_dict() for test in tests])

@app.route('/api/skill-tests/<int:test_id>/start', methods=['POST'])
def start_skill_test(test_id):
    session = Session()
    test = session.query(SkillTest).get_or_404(test_id)
    candidate_id = request.json.get('candidate_id')
    
    # Create test session
    session = TestSession(
        test_id=test_id,
        candidate_id=candidate_id,
        started_at=datetime.utcnow(),
        expires_at=datetime.utcnow() + timedelta(minutes=test.duration)
    )
    session.add(session)
    session.commit()
    
    return jsonify({
        'session_id': session.id,
        'test': test.to_dict(),
        'expires_at': session.expires_at.isoformat()
    })

@app.route('/api/skill-tests/submit', methods=['POST'])
def submit_test():
    session_id = request.json.get('session_id')
    answers = request.json.get('answers')
    
    session = Session()
    session = session.query(TestSession).get_or_404(session_id)
    if datetime.utcnow() > session.expires_at:
        raise APIError('Test session has expired')
    
    # Calculate score
    test = session.test
    # score = test.calculate_score(answers)
    
    # Save results
    session.completed_at = datetime.utcnow()
    # session.score = score
    session.answers = json.dumps(answers)
    session.commit()
    
    return jsonify({
        # 'score': score,
        # 'passing_score': test.passing_score,
        # 'passed': score >= test.passing_score,
        'feedback': test.generate_feedback(answers)
    })

# Interview Scheduling and Feedback
@app.route('/api/interviews/schedule', methods=['POST'])
def schedule_interview():
    data = request.json
    application_id = data.get('application_id')
    session = Session()
    application = session.query(Application).get_or_404(application_id)
    
    # Check for scheduling conflicts
    existing_interview = session.query(Interview).filter_by(application_id=application_id).filter_by(status='scheduled').first()
    if existing_interview:
        raise APIError('An interview is already scheduled for this application')
    
    # Create interview
    interview = Interview(
        application_id=application_id,
        scheduled_at=datetime.fromisoformat(data['scheduled_at']),
        interview_type=data['type'],
        location=data.get('location'),
        meeting_link=data.get('meeting_link'),
        interviewer_id=data['interviewer_id']
    )
    session.add(interview)
    
    # Update application status
    application.status = 'interview_scheduled'
    
    # Add to timeline
    timeline = ApplicationTimeline(
        application_id=application_id,
        status='interview_scheduled',
        notes=f"Interview scheduled for {data['scheduled_at']}"
    )
    session.add(timeline)
    session.commit()
    
    # Send notifications
    try:
        send_interview_invitation(
            application.email,
            interview.scheduled_at,
            interview.interview_type,
            interview.location or interview.meeting_link
        )
    except Exception as e:
        print(f"Failed to send interview invitation: {str(e)}")
    
    return jsonify({
        'message': 'Interview scheduled successfully',
        'interview': interview.to_dict()
    })

@app.route('/api/interviews/<int:interview_id>/feedback', methods=['POST'])
def submit_interview_feedback(interview_id):
    data = request.json
    session = Session()
    interview = session.query(Interview).get_or_404(interview_id)
    
    feedback = InterviewFeedback(
        interview_id=interview_id,
        interviewer_id=data['interviewer_id'],
        technical_score=data.get('technical_score'),
        communication_score=data.get('communication_score'),
        culture_fit_score=data.get('culture_fit_score'),
        strengths=data.get('strengths'),
        areas_for_improvement=data.get('areas_for_improvement'),
        notes=data.get('notes'),
        recommendation=data['recommendation']
    )
    session.add(feedback)
    
    # Update interview status
    interview.status = 'completed'
    interview.completed_at = datetime.utcnow()
    
    # Add to timeline
    timeline = ApplicationTimeline(
        application_id=interview.application_id,
        status='interview_completed',
        notes=f"Interview completed with recommendation: {data['recommendation']}"
    )
    session.add(timeline)
    session.commit()
    
    return jsonify({
        'message': 'Interview feedback submitted successfully',
        'feedback': feedback.to_dict()
    })

# Onboarding Process
@app.route('/api/onboarding/checklist', methods=['GET'])
def get_onboarding_checklist():
    application_id = request.args.get('application_id')
    session = Session()
    application = session.query(Application).get_or_404(application_id)
    
    if application.status != 'hired':
        raise APIError('Onboarding checklist is only available for hired candidates')
    
    checklist = session.query(OnboardingChecklist).filter_by(
        department=application.job.department
    ).first()
    
    if not checklist:
        raise APIError('Onboarding checklist not found for this department')
    
    return jsonify({
        'steps': json.loads(checklist.steps),
        'documents_required': json.loads(checklist.documents_required),
        'training_modules': json.loads(checklist.training_modules),
        'team_introductions': json.loads(checklist.team_introductions),
        'resources': json.loads(checklist.resources)
    })

@app.route('/api/onboarding/progress', methods=['POST'])
def update_onboarding_progress():
    data = request.json
    application_id = data.get('application_id')
    step_id = data.get('step_id')
    status = data.get('status')
    notes = data.get('notes')
    
    session = Session()
    progress = OnboardingProgress(
        application_id=application_id,
        step_id=step_id,
        status=status,
        notes=notes,
        completed_at=datetime.utcnow() if status == 'completed' else None
    )
    session.add(progress)
    session.commit()
    
    return jsonify({
        'message': 'Onboarding progress updated successfully',
        'progress': progress.to_dict()
    })

# Analytics and Reports
@app.route('/api/analytics/recruitment', methods=['GET'])
def get_recruitment_analytics():
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    department = request.args.get('department')
    
    session = Session()
    query = session.query(
        Job.department,
        func.count(Application.id).label('total_applications'),
        func.count(case([
            (Application.status == 'hired', 1)
        ])).label('total_hires'),
        func.avg(Application.overall_score).label('avg_score')
    ).join(Application)
    
    if start_date and end_date:
        query = query.filter(
            Application.applied_at.between(
                datetime.fromisoformat(start_date),
                datetime.fromisoformat(end_date)
            )
        )
    
    if department:
        query = query.filter(Job.department == department)
    
    query = query.group_by(Job.department)
    results = query.all()
    
    return jsonify([{
        'department': result[0],
        'total_applications': result[1],
        'total_hires': result[2],
        'hire_rate': round(result[2] / result[1] * 100, 2) if result[1] > 0 else 0,
        'average_score': round(result[3] or 0, 2)
    } for result in results])

@app.route('/apply/<int:job_id>')
def apply_page(job_id):
    return redirect(url_for('apply', job_id=job_id))

@app.route('/apply', methods=['GET'])
def apply():
    job_id = request.args.get('job_id')
    if not job_id:
        return redirect(url_for('index'))

    session = Session()
    try:
        job = session.query(Job).get(job_id)
        if not job:
            flash('Job not found', 'error')
            return redirect(url_for('index'))
        return render_template('apply.html', job=job)
    except Exception as e:
        print(f"Error in apply route: {str(e)}")
        flash('An error occurred', 'error')
        return redirect(url_for('index'))
    finally:
        session.close()

@app.route('/api/apply', methods=['POST'])
def submit_application():
    try:
        print("Received application submission")
        print("Form data:", request.form)
        print("Files:", request.files)

        if 'resume' not in request.files:
            return jsonify({'success': False, 'error': 'No resume file uploaded'}), 400
        
        file = request.files['resume']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'success': False, 'error': 'Invalid file type. Allowed types are PDF, DOC, DOCX'}), 400

        # Get form data with validation
        job_id = request.form.get('job_id')
        first_name = request.form.get('firstName')
        last_name = request.form.get('lastName')
        email = request.form.get('email')
        phone = request.form.get('phone')
        cover_letter = request.form.get('coverLetter')

        # Validate required fields
        if not all([job_id, first_name, last_name, email, phone]):
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400

        session = Session()
        try:
            # Verify job exists
            job = session.query(Job).get(job_id)
            if not job:
                return jsonify({'success': False, 'error': 'Job not found'}), 404

            # Save the resume file
            filename = secure_filename(f"{first_name}_{last_name}_{int(time.time())}_{file.filename}")
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            print(f"Saved resume to: {file_path}")

            # Process resume and calculate match score
            resume_text = ResumeProcessor.extract_text(file_path)
            match_score = ResumeProcessor.calculate_score(resume_text, job.requirements)
            print(f"Resume match score: {match_score}")

            # Create application record
            application = Application(
                job_id=job_id,
                first_name=first_name,
                last_name=last_name,
                email=email,
                phone=phone,
                resume_path=file_path,
                cover_letter=cover_letter,
                status='rejected' if match_score < 0.6 else 'pending',
                match_score=match_score,
                created_at=datetime.utcnow()
            )

            # Save to database
            session.add(application)
            session.commit()
            print(f"Created application record with ID: {application.id}")

            return jsonify({
                'success': True,
                'message': 'Application submitted successfully',
                'match_score': match_score,
                'status': application.status
            })

        except Exception as e:
            print(f"Error in submit_application: {str(e)}")
            session.rollback()
            return jsonify({'success': False, 'error': str(e)}), 500
        finally:
            session.close()

    except Exception as e:
        print(f"Unexpected error in submit_application: {str(e)}")
        return jsonify({'success': False, 'error': 'An unexpected error occurred'}), 500

# Admin routes
@app.route('/admin')
def admin_dashboard():
    return render_template('admin.html')

@app.route('/admin/jobs')
def admin_jobs():
    return render_template('admin.html')

@app.route('/api/admin/jobs', methods=['GET'])
def admin_list_jobs():
    try:
        session = Session()
        jobs = session.query(Job).all()
        
        result = []
        for job in jobs:
            result.append({
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None,
                'updated_at': job.updated_at.isoformat() if job.updated_at else None,
                'application_count': len(job.applications)
            })
        
        return jsonify({
            'success': True,
            'jobs': result
        })
    except Exception as e:
        print(f"Error getting jobs: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs/<int:job_id>', methods=['GET'])
def admin_get_job(job_id):
    try:
        session = Session()
        job = session.query(Job).get(job_id)
        
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        return jsonify({
            'success': True,
            'job': {
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None,
                'updated_at': job.updated_at.isoformat() if job.updated_at else None,
                'application_count': len(job.applications)
            }
        })
    except Exception as e:
        print(f"Error getting job: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs', methods=['POST'])
def admin_create_job():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'department', 'location', 'type', 'description', 'requirements']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'{field} is required'
                }), 400
        
        session = Session()
        
        # Create new job
        job = Job(
            title=data['title'],
            department=data['department'],
            location=data['location'],
            type=data['type'],
            description=data['description'],
            requirements=data['requirements'],
            is_active=data.get('is_active', True)
        )
        
        session.add(job)
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job created successfully',
            'job': {
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None,
                'updated_at': job.updated_at.isoformat() if job.updated_at else None
            }
        })
    except Exception as e:
        print(f"Error creating job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs/<int:job_id>', methods=['PUT'])
def admin_update_job(job_id):
    try:
        session = Session()
        job = session.query(Job).get(job_id)
        
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'title' in data:
            job.title = data['title']
        if 'department' in data:
            job.department = data['department']
        if 'location' in data:
            job.location = data['location']
        if 'type' in data:
            job.type = data['type']
        if 'description' in data:
            job.description = data['description']
        if 'requirements' in data:
            job.requirements = data['requirements']
        if 'is_active' in data:
            job.is_active = data['is_active']
        
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job updated successfully',
            'job': {
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None,
                'updated_at': job.updated_at.isoformat() if job.updated_at else None
            }
        })
    except Exception as e:
        print(f"Error updating job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs/<int:job_id>', methods=['DELETE'])
def admin_delete_job(job_id):
    try:
        session = Session()
        job = session.query(Job).get(job_id)
        
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        session.delete(job)
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job deleted successfully'
        })
    except Exception as e:
        print(f"Error deleting job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/applications', methods=['GET'])
def get_applications():
    try:
        session = Session()
        applications = session.query(Application).all()
        
        result = []
        for app in applications:
            # Get job details
            job = session.query(Job).get(app.job_id)
            if not job:
                continue
                
            result.append({
                'id': app.id,
                'first_name': app.first_name,
                'last_name': app.last_name,
                'candidate_name': f"{app.first_name} {app.last_name}",
                'email': app.email,
                'phone': app.phone,
                'job_title': job.title,
                'department': job.department,
                'match_score': app.match_score,
                'status': app.status,
                'resume_path': app.resume_path,
                'cover_letter': app.cover_letter,
                'created_at': app.created_at.isoformat() if app.created_at else None
            })
        
        return jsonify({
            'success': True,
            'applications': result
        })
    except Exception as e:
        print(f"Error getting applications: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/application/<int:application_id>', methods=['GET'])
def get_application(application_id):
    try:
        session = Session()
        application = session.query(Application).get(application_id)
        
        if not application:
            return jsonify({
                'success': False,
                'error': 'Application not found'
            }), 404
            
        # Get job details
        job = session.query(Job).get(application.job_id)
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
            
        result = {
            'id': application.id,
            'first_name': application.first_name,
            'last_name': application.last_name,
            'candidate_name': f"{application.first_name} {application.last_name}",
            'email': application.email,
            'phone': application.phone,
            'job_title': job.title,
            'department': job.department,
            'match_score': application.match_score,
            'status': application.status,
            'resume_path': application.resume_path,
            'cover_letter': application.cover_letter,
            'created_at': application.created_at.isoformat() if application.created_at else None
        }
        
        return jsonify({
            'success': True,
            'application': result
        })
    except Exception as e:
        print(f"Error getting application: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/application/<int:application_id>/status', methods=['PUT'])
def update_application_status(application_id):
    """Update application status and recalculate match score if needed"""
    try:
        data = request.get_json()
        if 'status' not in data:
            return jsonify({
                'success': False,
                'error': 'Status is required'
            }), 400

        valid_statuses = ['pending', 'reviewing', 'shortlisted', 'interviewed', 'offered', 'accepted', 'rejected']
        if data['status'] not in valid_statuses:
            return jsonify({
                'success': False,
                'error': f'Invalid status. Must be one of: {", ".join(valid_statuses)}'
            }), 400

        session = Session()
        try:
            application = session.query(Application).get(application_id)
            if not application:
                return jsonify({
                    'success': False,
                    'error': 'Application not found'
                }), 404

            # Update status
            old_status = application.status
            application.status = data['status']
            application.updated_at = datetime.utcnow()

            # Recalculate match score if needed
            if data.get('recalculate_score', False):
                try:
                    # Get job requirements
                    job = session.query(Job).get(application.job_id)
                    if job:
                        # Extract resume text
                        resume_text = ResumeProcessor.extract_text(application.resume_path)
                        
                        # Calculate new match score
                        application.match_score = calculate_match_score(
                            job.requirements,
                            resume_text,
                            {
                                'cover_letter': application.cover_letter
                            }
                        )
                except Exception as e:
                    print(f"Error recalculating match score: {str(e)}")
                    # Continue with status update even if score calculation fails

            session.commit()

            return jsonify({
                'success': True,
                'message': f'Application status updated from {old_status} to {application.status}',
                'application': {
                    'id': application.id,
                    'job_id': application.job_id,
                    'job_title': application.job.title if application.job else 'Unknown',
                    'first_name': application.first_name,
                    'last_name': application.last_name,
                    'email': application.email,
                    'phone': application.phone,
                    'status': application.status,
                    'match_score': application.match_score,
                    'created_at': application.created_at.isoformat() if application.created_at else None,
                    'updated_at': application.updated_at.isoformat() if application.updated_at else None
                }
            })

        except Exception as e:
            print(f"Error updating application status: {str(e)}")
            session.rollback()
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
        finally:
            session.close()

    except Exception as e:
        print(f"Error processing request: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Invalid request data'
        }), 400

@app.route('/api/admin/jobs', methods=['GET'])
def get_admin_jobs():
    try:
        session = Session()
        jobs = session.query(Job).all()
        
        result = [{
            'id': job.id,
            'title': job.title,
            'department': job.department,
            'location': job.location,
            'type': job.type,
            'description': job.description,
            'requirements': job.requirements,
            'is_active': job.is_active,
            'created_at': job.created_at.isoformat() if job.created_at else None
        } for job in jobs]
        
        return jsonify({
            'success': True,
            'jobs': result
        })
    except Exception as e:
        print(f"Error getting jobs: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs', methods=['POST'])
def create_job():
    try:
        session = Session()
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'department', 'location', 'type', 'description', 'requirements']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'{field} is required'
                }), 400
        
        # Create new job
        job = Job(
            title=data['title'],
            department=data['department'],
            location=data['location'],
            type=data['type'],
            description=data['description'],
            requirements=data['requirements'],
            is_active=data.get('is_active', True)
        )
        
        session.add(job)
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job created successfully',
            'job': {
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None
            }
        })
    except Exception as e:
        print(f"Error creating job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs/<int:job_id>', methods=['PUT'])
def update_job(job_id):
    try:
        session = Session()
        data = request.get_json()
        
        job = session.query(Job).get(job_id)
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        # Update fields if provided
        if 'title' in data:
            job.title = data['title']
        if 'department' in data:
            job.department = data['department']
        if 'location' in data:
            job.location = data['location']
        if 'type' in data:
            job.type = data['type']
        if 'description' in data:
            job.description = data['description']
        if 'requirements' in data:
            job.requirements = data['requirements']
        if 'is_active' in data:
            job.is_active = data['is_active']
        
        job.updated_at = datetime.utcnow()
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job updated successfully',
            'job': {
                'id': job.id,
                'title': job.title,
                'department': job.department,
                'location': job.location,
                'type': job.type,
                'description': job.description,
                'requirements': job.requirements,
                'is_active': job.is_active,
                'created_at': job.created_at.isoformat() if job.created_at else None
            }
        })
    except Exception as e:
        print(f"Error updating job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/jobs/<int:job_id>', methods=['DELETE'])
def delete_job(job_id):
    try:
        session = Session()
        job = session.query(Job).get(job_id)
        
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        # Instead of deleting, just set as inactive
        job.is_active = False
        job.updated_at = datetime.utcnow()
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Job deleted successfully'
        })
    except Exception as e:
        print(f"Error deleting job: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

# Admin application routes
@app.route('/api/admin/applications', methods=['GET'])
def admin_list_applications():
    try:
        session = Session()
        applications = session.query(Application).order_by(Application.created_at.desc()).all()
        
        result = []
        for application in applications:
            result.append({
                'id': application.id,
                'job_id': application.job_id,
                'job_title': application.job.title if application.job else 'Unknown',
                'first_name': application.first_name,
                'last_name': application.last_name,
                'email': application.email,
                'phone': application.phone,
                'resume_path': application.resume_path,
                'cover_letter': application.cover_letter,
                'match_score': application.match_score,
                'status': application.status,
                'created_at': application.created_at.isoformat() if application.created_at else None,
                'updated_at': application.updated_at.isoformat() if application.updated_at else None
            })
        
        return jsonify({
            'success': True,
            'applications': result
        })
    except Exception as e:
        print(f"Error getting applications: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/applications/<int:application_id>', methods=['GET'])
def admin_get_application(application_id):
    try:
        session = Session()
        application = session.query(Application).get(application_id)
        
        if not application:
            return jsonify({
                'success': False,
                'error': 'Application not found'
            }), 404
        
        result = {
            'id': application.id,
            'job_id': application.job_id,
            'job_title': application.job.title if application.job else 'Unknown',
            'first_name': application.first_name,
            'last_name': application.last_name,
            'email': application.email,
            'phone': application.phone,
            'resume_path': application.resume_path,
            'cover_letter': application.cover_letter,
            'match_score': application.match_score,
            'status': application.status,
            'created_at': application.created_at.isoformat() if application.created_at else None,
            'updated_at': application.updated_at.isoformat() if application.updated_at else None
        }
        
        return jsonify({
            'success': True,
            'application': result
        })
    except Exception as e:
        print(f"Error getting application: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/applications/<int:application_id>', methods=['PUT'])
def admin_update_application(application_id):
    try:
        session = Session()
        application = session.query(Application).get(application_id)
        
        if not application:
            return jsonify({
                'success': False,
                'error': 'Application not found'
            }), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'status' in data:
            application.status = data['status']
        if 'match_score' in data:
            application.match_score = data['match_score']
        
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Application updated successfully',
            'application': {
                'id': application.id,
                'job_id': application.job_id,
                'job_title': application.job.title if application.job else 'Unknown',
                'first_name': application.first_name,
                'last_name': application.last_name,
                'email': application.email,
                'phone': application.phone,
                'resume_path': application.resume_path,
                'cover_letter': application.cover_letter,
                'match_score': application.match_score,
                'status': application.status,
                'created_at': application.created_at.isoformat() if application.created_at else None,
                'updated_at': application.updated_at.isoformat() if application.updated_at else None
            }
        })
    except Exception as e:
        print(f"Error updating application: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

@app.route('/api/admin/applications/<int:application_id>', methods=['DELETE'])
def admin_delete_application(application_id):
    try:
        session = Session()
        application = session.query(Application).get(application_id)
        
        if not application:
            return jsonify({
                'success': False,
                'error': 'Application not found'
            }), 404
        
        # Delete resume file if it exists
        if application.resume_path and os.path.exists(application.resume_path):
            try:
                os.remove(application.resume_path)
            except Exception as e:
                print(f"Error deleting resume file: {str(e)}")
        
        session.delete(application)
        session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Application deleted successfully'
        })
    except Exception as e:
        print(f"Error deleting application: {str(e)}")
        session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

# Serve uploaded files
@app.route('/uploads/<path:filename>')
def serve_upload(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/admin/applications/<int:application_id>/match-score', methods=['GET'])
def get_match_score(application_id):
    try:
        session = Session()
        application = session.query(Application).get(application_id)
        
        if not application:
            return jsonify({
                'success': False,
                'error': 'Application not found'
            }), 404
        
        job = session.query(Job).get(application.job_id)
        if not job:
            return jsonify({
                'success': False,
                'error': 'Job not found'
            }), 404
        
        # Read resume content
        resume_text = ""
        if os.path.exists(application.resume_path):
            try:
                with open(application.resume_path, 'r', encoding='utf-8') as file:
                    resume_text = file.read()
            except Exception as e:
                print(f"Error reading resume: {str(e)}")
        
        # Calculate match score
        application_data = {
            'cover_letter': application.cover_letter
        }
        
        match_score = calculate_match_score(
            job.requirements,
            resume_text,
            application_data
        )
        
        # Update application match score
        application.match_score = match_score
        session.commit()
        
        return jsonify({
            'success': True,
            'match_score': match_score,
            'details': {
                'skills_match': 'Based on required skills in job description',
                'experience_match': 'Based on years of experience',
                'education_match': 'Based on required education level',
                'cover_letter_quality': 'Based on relevance to job requirements'
            }
        })
        
    except Exception as e:
        print(f"Error calculating match score: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
    finally:
        session.close()

if __name__ == '__main__':
    # Create tables
    Base.metadata.create_all(engine)
    
    app.run(debug=True)
